package com.dicoding.myhealth

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.myhealth.api.response.RekomendasiKaloriItem
import com.dicoding.myhealth.databinding.CardviewBinding

class HomeAdapter (private val dataList: List<RekomendasiKaloriItem>): RecyclerView.Adapter<HomeAdapter.ViewHolder>() {
    class ViewHolder (private val binding: CardviewBinding):
        RecyclerView.ViewHolder(binding.root)
        {
            fun bind(item: RekomendasiKaloriItem?) {
                item?.let {
                    binding.kalori.text = it.calories.toString()
                    binding.lemak.text = it.fat.toString()
                    binding.protein.text = it.protein.toString()
                }
            }
        }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = CardviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }
    override fun getItemCount(): Int {
       return dataList.size
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(dataList[position])
    }
}